---
name: opportunity-validation
description: Use when evaluating a product/project flow, blueprint, interactive demo, roadmap, feature priority, user journey, opportunity map, UX pain points, or iteration plan before deciding what to build next.
---

# Opportunity Validation

## Purpose

Use this skill to turn project materials, blueprints, state machines, demos, and user journeys into a validated iteration plan. The skill must produce evidence, opportunity scoring, solution experiments, three review rounds, and executable next steps.

The core rule: **no opportunity without journey evidence; no solution without validation; no iteration without a decision log.**

## When To Use

Use when the user asks to:
- run every project path and find real pain points
- review a blueprint or demo for opportunities
- compare competitor workflows and explain what to reference or avoid
- decide what to build next
- prioritize features, flows, or UX fixes
- validate whether a product idea is executable
- produce a roadmap, iteration plan, or PM/UX review
- compare product, interaction, engineering, and business value

Do not use for small isolated UI copy edits, simple bug fixes, or implementation-only tasks unless the user asks for product/UX opportunity analysis.

## Required Inputs

Collect or infer these before analysis. If some are missing, continue with explicit assumptions.

```json
{
  "projectProfile": {},
  "personas": [],
  "documents": [],
  "knowledgeBase": [],
  "competitors": [],
  "referenceProducts": [],
  "currentFlows": [],
  "blueprints": [],
  "interactionSkillV3": {},
  "demoSchema": {},
  "stateMachines": [],
  "qaProtocol": {},
  "currentDemoHtml": ""
}
```

## Mandatory Framework Stack

Apply these frameworks in this order:

1. **Persona**: one journey map per user type.
2. **JTBD / Jobs Scoping**: define the real job and scope boundaries.
3. **Competitor Workflow Reverse Analysis**: compare how public competitors solve the same job and why.
4. **User Journey Map**: map scenario, touchpoints, actions, feedback, emotion, pain, opportunity.
5. **Service Blueprint**: map frontstage, backstage, support systems, waiting points, failure points.
6. **Opportunity Solution Tree**: outcome -> opportunities -> solutions -> experiments.
7. **Problem-Solution Fit**: verify problem evidence and solution evidence.
8. **Kano**: classify features as must-be, performance, attractive, indifferent, reverse.
9. **RICE**: score reach, impact, confidence, effort.
10. **Feature Priority Pyramid**: classify foundation, reliability, usability, experience, differentiation.
11. **Three-Round Review**: UX, product value, engineering execution.

## Execution Workflow

### 1. Build Project Context Brief

Summarize:
- product positioning
- target users
- current stage
- primary jobs
- available materials
- current blueprints and demos
- known risks and assumptions

Output: `projectContextBrief`.

### 2. Define Personas And Jobs

Create 2-5 personas when possible. Each persona must include:

```json
{
  "id": "pm",
  "role": "产品经理",
  "goal": "把 PRD 快速变成可评审的交互方案",
  "constraints": ["时间少", "需要可展示", "需要可落地"],
  "jobToBeDone": "当我有一个产品文档时，我想快速得到蓝图、路径、Demo 和迭代建议，以便推进评审和开发。",
  "jobStages": ["Define", "Locate", "Prepare", "Confirm", "Execute", "Monitor", "Modify", "Conclude"]
}
```

### 3. Run Competitor Workflow Reverse Analysis

Competitor analysis is mandatory for P0/P1 decisions. It must compare flows for the same user job, not generic product positioning.

Use only:
- public product pages
- public documentation
- user-provided screenshots, recordings, exports, or notes
- first-hand observations from authorized pages

Do not claim access to hidden prompts, private agent configuration, non-public thinking chains, internal Markdown, or protected systems. If a competitor detail is inferred, mark it as `inference`.

#### 3.1 Define The Comparison Task

Create one or more comparison tasks from the current project job:

```json
{
  "taskId": "upload-prd-to-interactive-demo",
  "job": "上传产品文档并得到可评审的流程蓝图和交互 Demo",
  "input": ["产品文档", "参考站点", "现有项目资料"],
  "expectedOutput": ["蓝图", "交互路径", "Demo", "评审建议", "开发任务"],
  "successCriteria": ["不用输入也能预览价值", "状态透明", "失败可恢复", "产物可沉淀"]
}
```

#### 3.2 Select Competitor Set

Use three competitor types when possible:

```json
{
  "directCompetitors": ["同类 PM/UX/AI agent 工具"],
  "indirectCompetitors": ["Coze", "Notion AI", "Feishu/Lark", "Copilot Studio"],
  "benchmarkProducts": ["Figma", "Linear", "Cursor", "Lovable"]
}
```

If the user provides specific competitors, include them first. If public evidence is missing, record the gap instead of inventing behavior.

#### 3.3 Reconstruct Competitor Flows

For every relevant competitor, output:

```json
{
  "competitor": "",
  "sourceType": "public-doc|public-page|user-screenshot|authorized-observation|inference",
  "sourceEvidence": [],
  "targetTask": "",
  "entryPoint": "",
  "inputMethod": "",
  "firstRunExperience": "",
  "emptyState": "",
  "uploadPlacement": "",
  "generationFeedback": "",
  "humanConfirmation": "",
  "artifactPersistence": "",
  "retryOrVersioning": "",
  "failureRecovery": "",
  "handoffToExecution": "",
  "notableInteractionDetails": []
}
```

#### 3.4 Explain Why They Do It

Every competitor pattern must include a reason analysis:

```json
{
  "pattern": "",
  "competitorsUsingIt": [],
  "productReason": "",
  "interactionReason": "",
  "technicalReason": "",
  "businessReason": "",
  "riskOrTradeoff": ""
}
```

Common reason categories:
- reduce first-use friction
- make AI progress observable
- split long-running work into confirmable stages
- increase trust through evidence and source references
- make generated artifacts reusable
- keep expert controls hidden until needed
- protect users from destructive or irreversible actions

#### 3.5 Convert References Into Decisions

Do not stop at "can reference". Convert each useful pattern into a decision:

```json
{
  "referenceId": "",
  "competitorPattern": "",
  "whyItWorks": "",
  "whatToReference": "",
  "whatNotToCopy": "",
  "ourBetterVersion": "",
  "targetFlow": "",
  "targetSurface": "page|modal|drawer|inline-panel|side-panel|new-tab|toast|status-page",
  "priorityImpact": "raise|keep|lower",
  "evidenceStrength": "strong|medium|weak",
  "openQuestions": []
}
```

Required comparison conclusions:
- What competitors make easy that we currently make hard.
- What competitors hide that we should expose.
- What competitors expose that we should simplify.
- Where we can be more trustworthy, more reviewable, or more executable.
- Which ideas should be rejected because they add configuration burden without user value.

Output: `competitorWorkflowAnalysis`.

### 4. Run Journey Simulations

For each persona, simulate the most important flows. At minimum cover:
- first-time empty input
- upload document or URL
- parse/generate blueprint
- inspect interaction path and Skill v3
- generate 1:1 demo
- switch style or interaction mode
- handle upload failure
- handle permission/error/empty state
- save/export/import to knowledge
- return and modify requirements

Each journey must include:

```json
{
  "journeyId": "",
  "personaId": "",
  "scenario": "",
  "start": "",
  "end": "",
  "successCriteria": [],
  "touchpoints": [
    {
      "step": 1,
      "touchpoint": "",
      "userAction": "",
      "systemFeedback": "",
      "emotion": "",
      "emotionScore": 0,
      "painPoint": "",
      "evidence": [],
      "opportunityHint": ""
    }
  ]
}
```

### 5. Build Service Blueprints

For every P0/P1 journey, map:

```json
{
  "journeyId": "",
  "userAction": "",
  "frontstage": "",
  "backstage": "",
  "supportSystem": "",
  "waitingPoints": [],
  "failurePoints": [],
  "missingSignals": [],
  "requiredStateExposure": []
}
```

Use this to identify hidden backend states that must become visible UI feedback.

### 6. Extract Pain Point Evidence

Pain points must come from a journey step or service blueprint. No unsupported guesses.

```json
{
  "id": "",
  "title": "",
  "sourceJourney": "",
  "triggerStep": "",
  "observedIssue": "",
  "userImpact": "",
  "severity": "P0|P1|P2|P3",
  "evidence": [],
  "emotionLowPoint": true
}
```

Competitor evidence can strengthen or weaken a pain point, but cannot replace journey evidence from the current product.

### 7. Build Opportunity Solution Tree

Start from product outcomes, not features.

```json
{
  "outcome": "提升用户从资料到可交互 Demo 的完成率和信任感",
  "opportunities": [
    {
      "id": "",
      "title": "",
      "sourcePainPoints": [],
      "opportunityType": "fix-pain|amplify-delight",
      "solutions": [],
      "experiments": []
    }
  ]
}
```

Each solution must include:
- target flows
- target blueprints
- competitor references and anti-patterns
- surface decision
- UI nodes
- state machine changes
- demo validation
- expected value
- risks

### 8. Decide Product Surface

Every solution must decide its form:

```json
{
  "recommended": "page|modal|drawer|inline-panel|side-panel|new-tab|toast|status-page",
  "reason": "",
  "alternatives": [
    { "surface": "", "tradeoff": "" }
  ],
  "placement": "",
  "entryPoint": "",
  "exitPath": ""
}
```

Rules:
- Use `inline-panel` for progress, parsing, local errors, lightweight feedback.
- Use `drawer` for side-by-side review/edit.
- Use `modal` for confirmation and destructive/high-cost actions.
- Use `new-tab` for 1:1 demo, code preview, or external pages.
- Use `page` for long workflows and durable assets.
- Use `side-panel` for requirement tree, QA, opportunities, and review comments.

### 9. Score And Prioritize

Each opportunity must include product, interaction, Kano, RICE, and pyramid scores.

```json
{
  "productReview": {
    "userValue": 0,
    "frequency": 0,
    "trustImpact": 0,
    "businessValue": 0,
    "reuseValue": 0
  },
  "interactionReview": {
    "clarity": 0,
    "feedback": 0,
    "recoverability": 0,
    "cognitiveLoad": 0,
    "flowContinuity": 0
  },
  "kano": "must-be|performance|attractive|indifferent|reverse",
  "rice": {
    "reach": 0,
    "impact": 0,
    "confidence": 0,
    "effort": 0,
    "score": 0
  },
  "pyramidLevel": "L1-foundation|L2-reliability|L3-usability|L4-experience|L5-differentiation",
  "competitorReferenceValue": 0,
  "competitorDifferentiationValue": 0,
  "priority": "P0|P1|P2|P3",
  "weight": 0
}
```

Recommended formulas:

```text
RICE = reach * impact * confidence / effort
weight = userValue*1.4 + frequency*1.1 + trustImpact*1.2 + recoverability + flowContinuity + competitorReferenceValue*0.8 + competitorDifferentiationValue*1.1 - effort*1.3 - riskPenalty
```

Priority guidance:
- `P0`: blocks task completion, trust, data safety, generation reliability, or return/recovery.
- `P1`: improves completion rate, clarity, reviewability, or cross-project reuse.
- `P2`: improves efficiency, polish, or expert workflows.
- `P3`: exploratory or delight-only.

### 10. Run Three Review Rounds

#### Round 1: UX Review

Check:
- user knows where they are
- user knows what happened
- user knows next step
- feedback is close to trigger
- empty/error/permission/unsaved states are recoverable
- surface choice does not interrupt the wrong task
- referenced competitor pattern is adapted to this user's job, not copied blindly

Output: `uxReviewPatch`.

#### Round 2: Product Value Review

Check:
- opportunity maps to a real outcome
- pain has evidence
- benefit is measurable
- feature fits Kano and pyramid level
- RICE confidence is high enough
- opportunity is not just a nice-to-have
- competitor evidence explains why the opportunity matters or why differentiation is possible

Output: `productOpportunityPatch`.

#### Round 3: Execution Review

Check:
- can be represented in `stateMachines`
- can be represented in `demoSchema`
- can be validated in demo
- does not break multi-project behavior
- has clear data dependencies
- has testable acceptance criteria
- competitor-inspired behavior is feasible with current data, tools, and UI architecture

Output: `executionPatch`.

### 11. Produce Final Outputs

The final answer must include:

```json
{
  "projectContextBrief": {},
  "personaMaps": [],
  "jobMaps": [],
  "competitorWorkflowAnalysis": {
    "comparisonTasks": [],
    "competitorFlowMatrix": [],
    "patternReasoning": [],
    "referenceDecisions": [],
    "differentiationStrategy": []
  },
  "journeyMaps": [],
  "serviceBlueprints": [],
  "painPointEvidenceMatrix": [],
  "opportunitySolutionTree": {},
  "surfaceDecisions": [],
  "priorityMap": [],
  "threeRoundReview": {
    "uxReviewPatch": {},
    "productOpportunityPatch": {},
    "executionPatch": {}
  },
  "finalIterationPlan": [],
  "developmentTasks": []
}
```

## Quality Gates

Before finishing, verify:
- Competitor analysis is task-based, sourced, and clearly marks inferences.
- Every referenced competitor pattern explains why it works and what not to copy.
- Every P0/P1 opportunity states whether competitor evidence raises, lowers, or does not affect priority.
- Every P0/P1 opportunity has journey evidence.
- Every solution has a surface decision.
- Every surface decision has alternatives and tradeoffs.
- Every solution maps to flows, blueprints, UI nodes, and state changes.
- Every opportunity has product score, interaction score, Kano, RICE, pyramid level, priority, and weight.
- Three review rounds produce concrete patches.
- Final iteration plan is ordered and executable.

## Output Format For Users

When presenting the result, use this order:

1. **结论**
2. **竞品流程对比与可参考点**
3. **最重要机会点 Top 5**
4. **每个机会点的证据**
5. **推荐方案与形态**
6. **产品/交互/工程评分**
7. **三轮评审后的修改**
8. **最终迭代计划**
9. **可执行开发任务**

Keep claims grounded in journey evidence. Clearly mark assumptions.
